package TrabalhoPratico.Itens;

/**
 * Enumeração que representa os tipos de herói.
 */
public enum TiposHeroi {
    CAVALEIRO,
    ARQUEIRO,
    FEITICEIRO;
}